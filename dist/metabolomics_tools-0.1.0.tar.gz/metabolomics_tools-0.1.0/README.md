## 📦 PyPI
- For documentation refer to

https://metabolomics_tools.readthedocs.io/en/latest/metabolomics_tools.html

You can install this package via pip:

```
pip install metabolomics_tools
```

or first clone the package and then
```
pip install -e .
```


